<?php
$viewdefs ['Alerts'] =
array(

);