<?php

$app_list_strings["moduleList"]["SecurityGroups"] = "Gestion des équipes";
$app_strings['LBL_LOGIN_AS'] = "Ouverture comme ";
$app_strings['LBL_LOGOUT_AS'] = "Déconnexion comme ";
$app_strings['LBL_SECURITYGROUP'] = 'Gestion des équipe';

?>