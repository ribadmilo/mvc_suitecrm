<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Gerenciamento de Grupos de Segurança';
$app_strings['LBL_LOGIN_AS'] = "Iniciar sessão como ";
$app_strings['LBL_LOGOUT_AS'] = "Terminar sessão como ";
$app_strings['LBL_SECURITYGROUP'] = 'Gerenciamento de Grupo';

?>