<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Administración de Grupos de Seguridad';
$app_strings['LBL_LOGIN_AS'] = "Conexión como ";
$app_strings['LBL_LOGOUT_AS'] = "Cerrar sesión como ";
$app_strings['LBL_SECURITYGROUP'] = 'Administración de Grupo';

?>