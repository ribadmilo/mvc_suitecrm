<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Gestione Gruppi di Sicurezza';
$app_strings['LBL_LOGIN_AS'] = "Inizio attività come ";
$app_strings['LBL_LOGOUT_AS'] = "Termine attività come ";
$app_strings['LBL_SECURITYGROUP'] = 'Gestione Gruppi';

?>