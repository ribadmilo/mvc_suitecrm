<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$suitecrm_version      = '7.3.1';
$suitecrm_timestamp    = '2015-08-25 17:00pm';